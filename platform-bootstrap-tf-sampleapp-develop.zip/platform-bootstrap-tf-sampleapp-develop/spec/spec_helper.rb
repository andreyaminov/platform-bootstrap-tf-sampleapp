require 'pipeline-tasks/specs'

INFRA_DNS_OUTPUTS = read_json(target('infra-sampleapp_dns.json'))
