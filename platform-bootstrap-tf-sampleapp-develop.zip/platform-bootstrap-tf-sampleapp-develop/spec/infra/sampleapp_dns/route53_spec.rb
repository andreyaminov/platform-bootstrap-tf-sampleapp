# frozen_string_literal: true

require 'spec_helper'

describe route53_hosted_zone(INFRA_DNS_OUTPUTS['hosted_zone']) do
  it { should have_record_set('sampleapp.itsreaning.com.') }
end
