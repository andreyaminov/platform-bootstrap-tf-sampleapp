# frozen_string_literal: true

include_controls 'inspec-kubernetes'

control 'Sampleapp K8s Resources' do
  title 'Sampleapp K8s Resources'
  desc 'Sampleapp K8s Resources'

  describe k8s_deployment(name: 'sampleapp-sample-app', namespace: input('namespace'), kube_config_file: input('kube_config_file')) do
    its('replicas') { should eq 1 }
    its('available_replicas') { should eq 1 }
    its('ready_replicas') { should eq 1 }
  end
end
